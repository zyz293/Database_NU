# run HW3

import SQLHW3
c = SQLHW3.CaesarSys()
